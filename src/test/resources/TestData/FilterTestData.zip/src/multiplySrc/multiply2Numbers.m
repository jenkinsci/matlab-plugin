function out = multiply2Numbers(num1,num2)
%MULNUM Summary of this function goes here
%   Detailed explanation goes here
out = num1 * num2;
end

